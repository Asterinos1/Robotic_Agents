import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description(): 
    pkg_ros_gz_example_gazebo = get_package_share_directory('ros_gz_example_gazebo')
    pkg_ros_gz_example_description = get_package_share_directory('ros_gz_example_description')
    pkg_ros_gz_example_bringup = get_package_share_directory('ros_gz_example_bringup')

    world_file = os.path.join(pkg_ros_gz_example_gazebo, 'worlds', 'env_only.sdf')
    urdf_file = os.path.join(pkg_ros_gz_example_description, 'urdf', 'robot4.urdf')

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory('ros_gz_sim'), 'launch', 'gz_sim.launch.py')
        ),
        launch_arguments={'gz_args': f'-r {world_file}'}.items(),
    )

    spawn_robot = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-file', urdf_file,
            '-name', 'my_robot',
            '-z', '0.5'
        ],
        output='screen'
    )

    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '--ros-args',
            '-p', f'config_file:={os.path.join(pkg_ros_gz_example_bringup, "config", "bridge.yaml")}'
        ],
        output='screen'
    )

    return LaunchDescription([
        gazebo,
        spawn_robot,
        bridge
    ])
